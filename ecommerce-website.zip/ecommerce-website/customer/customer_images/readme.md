
**Database Name: ecom_store**

**Developed by Santanu Roy**

**Recommended PHP Version 5.6 and Newer**

**Admin Panel: /admin_area **

**Admin Login Details**

Username: admin@mail.com
Password: Password@123

Instruction: How To Run?
After you finish downloading the project, unzip the project file and head over to your XAMPP directory.
There you’ll find a folder naming “htdocs”.
Inside the “htdocs” folder, paste the project folder (not the .zip one, but the extracted one).
Open your favorite browser; Google Chrome
Then, go to URL “http://localhost/phpmyadmin“.
Create a Database with a name that is provided inside the “01 LOGIN DETAILS & PROJECT INFO.txt”.
Click on the “Import” tab and choose the database file (.sql) which is provided under the folder naming “DATABASE FILE”.
After setting up all these, go to URL “http://localhost/[ PROJECT_FOLDER_NAME ]/“
All the login details are provided inside the project folder, check that out and enter in order to use it.
